# MICCAI_2014_MLC
Predicting Binary and Continuous Phenotypes from Structural Brain MRI Data
